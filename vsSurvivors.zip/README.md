# vsSurvivors
A custom gamemode where you take control of the inhabitants of Petrichor V!. Stop 4 AI-controlled survivors from escaping the moon and beating the game.

## Overview:
* Survivors do not respawn
* You respawn as another enemy upon death (endlessly)
* Survivors will activate the teleporter after some delay
* Every minute (configurable), both the enemies and survivors will gain a permanent item from the pool of a small chest (configurable)
* Enemies spawn with a few items and increased health
* Survivors are 1.5x larger and have slightly increased health
